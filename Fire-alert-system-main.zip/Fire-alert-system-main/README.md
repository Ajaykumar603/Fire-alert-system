# Fire-alert-system
Hey,Try the circuit here : https://www.tinkercad.com/things/8BUtZwrzHB1-fire-safety-/editel
